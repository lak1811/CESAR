
from django.http import HttpResponse
# Create your views here.
from django.shortcuts import render, redirect
from .forms import FileUploadForm
from . import views
from .dash_app import app


def index(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('dash_view')  # Redirect to a success page
    else:
        form = FileUploadForm()
    return render(request, 'testapp1/index.html', {'form': form})

def dash_view(request):
    dash_layout = app.layout
    return render(request, 'testapp1/dash_template.html',{'dash_app_content': dash_layout})