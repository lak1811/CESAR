from django.urls import path
from . import views

urlpatterns=[
    path("testapp1/",views.index),
    path('', views.index, name='index'),
    path('dash/', views.dash_view, name='dash_view')
    



]